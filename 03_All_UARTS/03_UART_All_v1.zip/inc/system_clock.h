#ifndef __SYSTEM_CLOCK_H
#define __SYSTEM_CLOCK_H
#include "stm32f4xx.h"

void SystemClock_Config(void);

#endif
