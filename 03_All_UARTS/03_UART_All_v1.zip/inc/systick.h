#ifndef SYSTICK_H
#define SYSTICK_H

#include "stm32f446xx.h"
#include <stdint.h>

void sysTickDelay(int count);
#endif
